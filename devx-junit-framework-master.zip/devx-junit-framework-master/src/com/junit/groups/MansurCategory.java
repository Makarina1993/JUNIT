package com.junit.groups;

public class MansurCategory {
}

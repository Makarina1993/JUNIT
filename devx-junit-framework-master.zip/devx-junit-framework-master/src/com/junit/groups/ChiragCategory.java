package com.junit.groups;

public class ChiragCategory {

}

package com.junit.groups;

import org.junit.experimental.categories.Category;

public class SmokeCategory {

}

package com.junit.class02;

public class Calculator {

    public double sum(int a, int b) {
        return a + b;
    }

    public double sub(int a, int b) {
        return a - b;
    }

    public double div(int a, int b) {
        return a / b;
    }

    public double mul(int a, int b) {
        return a * b;
    }
}
